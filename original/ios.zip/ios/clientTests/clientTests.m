//
//  clientTests.m
//  clientTests
//
//  Created by nito on 26/10/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "clientTests.h"

@implementation clientTests
- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"Unit tests are not implemented yet in clientTests");
}

@end
