//
//  clientTests.h
//  clientTests
//
//  Created by nito on 26/10/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface clientTests : XCTestCase

@end
